"""Regenerate the linear OLS probe R^2 figure (Plot 3 of
``plot_optimal_orth_direction_across_layers``).

Mirrors the first invocation of the function in
``notebooks/Linear.ipynb`` and saves ``fig_r2`` to the paper's Figs folder.
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from icl.linear.analysis import plot_optimal_orth_direction_across_layers
from icl.utils.unified_interface import get_exp_name


exp_name = get_exp_name(
    "linear",
    10,
    n_layer=16,
    total_steps=30_000,
    warmup_steps=15_000,
    batch_size=256,
    max_grad_norm=1.0,
)

save_path = os.path.join(
    os.path.dirname(__file__), '..', '..',
    'representation-geometry-two-modes', 'Figs', 'linear_ols_probe_r2.png',
)

fig, fig_loss, fig_r2, fig_filt, fig_per_task, all_results = (
    plot_optimal_orth_direction_across_layers(
        exp_name=exp_name,
        layers=range(16),
        n_directions=2,
        n_opt_steps=25,
        opt_lr=0.01,
        opt_B=256,
        patience=50,
        grad_clip_norm=1.0,
        n_samples_eval=2**10,
        n_samples_probe=2**10,
        n_ood=2**10,
        scale=2,
        opt_source="minor",
        extraction_point="post_mlp",
        probe_method="averaging",
        figsize=(6, 4),
        show=False,
    )
)

fig_r2.savefig(save_path, dpi=300, bbox_inches="tight")
print(f"\nSaved fig_r2 to: {save_path}")
