from __future__ import annotations

from typing import Literal, List, Sequence

import torch

from icl.models.kv_cache import KVCache

ActivationKind = Literal["attn_block", "mlp"]


def _get_n_emb(config) -> int:
    n_emb = getattr(config.model, "emb_dim", getattr(config.model, "n_embd", None))
    if n_emb is None:
        raise ValueError("config.model must contain emb_dim or n_embd")
    return int(n_emb)


def _alloc_kv_caches(
    model: torch.nn.Module,
    batch: int,
    max_len: int,
    *,
    device: torch.device,
    dtype: torch.dtype,
) -> List[KVCache]:
    caches: List[KVCache] = []
    for layer in model.layers:
        mha = layer.attn_block.MHA
        H = int(mha.n_head)
        Dh = int(mha.head_dim)
        k = torch.empty((batch, H, max_len, Dh), device=device, dtype=dtype)
        v = torch.empty_like(k)
        caches.append(KVCache(k=k, v=v, cur_len=0))
    return caches


def _reset_caches(caches: Sequence[KVCache]) -> None:
    # Uses KVCache.reset() (exists in your kv_cache.py).
    for c in caches:
        c.reset()


@torch.inference_mode()
def _forward_prefix(model: torch.nn.Module, tokens: torch.Tensor, kv_caches: Sequence[KVCache]) -> None:
    # tokens: (B, Tprefix) on model device
    x = model.embed(tokens)
    for i, layer in enumerate(model.layers):
        x = layer.attn_block(x, kv_cache=kv_caches[i], cache_pos=None, update_cache=True)
        x = layer.mlp(x)


@torch.inference_mode()
def _forward_one_collect(
    model: torch.nn.Module,
    token: torch.Tensor,  # (B,1) on model device
    kv_caches: Sequence[KVCache],
    *,
    activation: ActivationKind,
) -> torch.Tensor:
    """
    Returns (n_layers, B, D) for the (only) token; does NOT advance cache length.
    Preallocates output to avoid list+stack overhead.
    """
    x = model.embed(token)
    n_layers = len(model.layers)
    B = x.size(0)
    D = x.size(-1)

    out = torch.empty((n_layers, B, D), device=x.device, dtype=x.dtype)

    if activation == "attn_block":
        for i, layer in enumerate(model.layers):
            x = layer.attn_block(x, kv_cache=kv_caches[i], cache_pos=None, update_cache=False)
            out[i].copy_(x[:, -1, :])
            x = layer.mlp(x)
    elif activation == "mlp":
        for i, layer in enumerate(model.layers):
            x = layer.attn_block(x, kv_cache=kv_caches[i], cache_pos=None, update_cache=False)
            x = layer.mlp(x)
            out[i].copy_(x[:, -1, :])
    else:
        raise ValueError(f"Unknown activation kind: {activation}")

    return out


def _get_flash_flags(model: torch.nn.Module) -> List[bool]:
    flags: List[bool] = []
    for layer in model.layers:
        mha = layer.attn_block.MHA
        flags.append(bool(getattr(mha, "flash", False)))
    return flags


def _set_flash_flags(model: torch.nn.Module, flags: Sequence[bool]) -> None:
    for layer, f in zip(model.layers, flags):
        mha = layer.attn_block.MHA
        if hasattr(mha, "flash"):
            mha.flash = bool(f)


@torch.inference_mode()
def compute_hiddens_onepos_all_layers_kvcached(
    config,
    model: torch.nn.Module,
    samples: torch.Tensor,
    activation: ActivationKind = "attn_block",
    dtype_out: torch.dtype = torch.float16,
    # chunk sizes
    k_step: int = 4,
    t_step: int = 32,
    v_step: int = 64,
    b_step: int = 32,
    # transfer / memory
    pin_samples: bool = True,
    pin_output: bool = False,
    # KV cache / attention backend
    allow_flash_kv_cache: bool = False,
    # correctness checks (debug)
    debug_check_shared_prefix: bool = False,
) -> torch.Tensor:
    """
    samples: (n_tasks, Tm1, V, B, Sfull) on CPU (token ids)
    Returns: (n_layers, n_tasks, Tm1, V, B, D) on CPU

    Uses KV cache to reuse the prefix for each (k,t,b) across all v:
      1) build cache on prefix tokens [0..pos-1] where pos=2*t+1 (take v=0 prefix)
      2) run a 1-token forward at pos for each v with update_cache=False

    Notes:
      - Assumes that for fixed (k,t,b), all candidates v share the same prefix [:pos].
      - If your flash+kv_cache path is correct, set allow_flash_kv_cache=True.
    """

    if activation not in ("attn_block", "mlp"):
        raise ValueError(f"activation must be 'attn_block' or 'mlp', got {activation!r}")

    # normalize chunk sizes once
    k_step = max(1, int(k_step))
    t_step = max(1, int(t_step))
    v_step = max(1, int(v_step))
    b_step = max(1, int(b_step))

    # model placement / dtype
    param0 = next(model.parameters())
    device = param0.device
    on_cuda = (device.type == "cuda")
    cache_dtype = param0.dtype
    model.eval()

    # validate samples
    if samples.device.type != "cpu" or samples.ndim != 5:
        raise ValueError("samples must be a 5D CPU tensor (n_tasks, Tm1, V, B, Sfull)")
    if samples.dtype != torch.long:
        samples = samples.long()

    # Pinning the whole tensor can be expensive; kept for compatibility.
    # This refactor does NOT rely on it for async H2D (it uses small pinned staging buffers).
    if on_cuda and pin_samples and not samples.is_pinned():
        samples = samples.pin_memory()

    n_tasks, Tm1, V, B, Sfull = samples.shape
    D = _get_n_emb(config)
    n_layers = len(model.layers)

    out_pin = bool(on_cuda and pin_output)
    out = torch.empty(
        (n_layers, n_tasks, Tm1, V, B, D),
        device="cpu",
        dtype=dtype_out,
        pin_memory=out_pin,
    )
    async_copy = bool(on_cuda and out_pin)

    flash_flags = _get_flash_flags(model)
    need_disable_flash = (not allow_flash_kv_cache) and any(flash_flags)
    probe_flags = [False] * len(flash_flags)

    try:
        for k0 in range(0, n_tasks, k_step):
            k1 = min(k0 + k_step, n_tasks)
            nK = k1 - k0

            for t0 in range(0, Tm1, t_step):
                t1 = min(t0 + t_step, Tm1)
                max_pos = 2 * (t1 - 1) + 1
                if max_pos >= Sfull:
                    raise ValueError("pos(t) exceeds sequence length")
                max_len = max_pos + 1

                for b0 in range(0, B, b_step):
                    b1 = min(b0 + b_step, B)
                    bchunk = b1 - b0
                    Bflat = nK * bchunk

                    # Allocate KV caches once for this (k,t-chunk,b) tile.
                    kv_caches = _alloc_kv_caches(model, Bflat, max_len, device=device, dtype=cache_dtype)

                    # Reusable staging buffers to avoid repeated CPU/GPU allocations.
                    if on_cuda:
                        # Small pinned CPU staging buffers (cheap, and makes H2D reliably non_blocking).
                        prefix_cpu = torch.empty((Bflat, max_pos), device="cpu", dtype=torch.long, pin_memory=True)
                        toks_cpu = torch.empty((Bflat, v_step), device="cpu", dtype=torch.long, pin_memory=True)

                        # GPU buffers
                        prefix_gpu = torch.empty((Bflat, max_pos), device=device, dtype=torch.long)
                        toks_gpu = torch.empty((Bflat, v_step), device=device, dtype=torch.long)
                    else:
                        prefix_cpu = toks_cpu = prefix_gpu = toks_gpu = None

                    # Temp buffer on the model device for one v-chunk (reused).
                    tmp = torch.empty((n_layers, nK, v_step, bchunk, D), device=device, dtype=dtype_out)

                    for t in range(t0, t1):
                        pos = 2 * t + 1
                        if pos >= Sfull:
                            raise ValueError("pos(t) exceeds sequence length")

                        _reset_caches(kv_caches)

                        # Optional correctness check: all v share prefix
                        if debug_check_shared_prefix and V > 1 and pos > 0:
                            pref0 = samples[k0:k1, t, 0, b0:b1, :pos]
                            pref1 = samples[k0:k1, t, V - 1, b0:b1, :pos]
                            if not torch.equal(pref0, pref1):
                                raise ValueError("cached-prefix assumption violated: prefixes differ across v")

                        # -----------------
                        # Prefix build (v=0)
                        # -----------------
                        if on_cuda:
                            # Fill pinned CPU buffer as (nK, bchunk, max_pos) so no reshape/contiguous needed.
                            prefix_cpu_view = prefix_cpu.view(nK, bchunk, max_pos)
                            prefix_src = samples[k0:k1, t, 0, b0:b1, :pos]  # (nK,bchunk,pos)
                            prefix_cpu_view[:, :, :pos].copy_(prefix_src)

                            # H2D (async)
                            prefix_gpu[:, :pos].copy_(prefix_cpu[:, :pos], non_blocking=True)
                            prefix = prefix_gpu[:, :pos]
                        else:
                            prefix = samples[k0:k1, t, 0, b0:b1, :pos].reshape(Bflat, pos)

                        # flash ON for prefix build (original behavior)
                        if need_disable_flash:
                            _set_flash_flags(model, flash_flags)
                        _forward_prefix(model, prefix, kv_caches)

                        # flash OFF for probe if requested
                        if need_disable_flash:
                            _set_flash_flags(model, probe_flags)

                        # -----------------
                        # Probe tokens (all v)
                        # -----------------
                        for v0 in range(0, V, v_step):
                            v1 = min(v0 + v_step, V)
                            vchunk = v1 - v0

                            if on_cuda:
                                toks_cpu_view = toks_cpu.view(nK, bchunk, v_step)

                                tok_src = samples[k0:k1, t, v0:v1, b0:b1, pos]  # (nK,vchunk,bchunk)
                                tok_src = tok_src.permute(0, 2, 1)  # (nK,bchunk,vchunk) view

                                toks_cpu_view[:, :, :vchunk].copy_(tok_src)
                                toks_gpu[:, :vchunk].copy_(toks_cpu[:, :vchunk], non_blocking=True)
                                tok_ids = toks_gpu[:, :vchunk]
                            else:
                                tok_ids = samples[k0:k1, t, v0:v1, b0:b1, pos]  # (nK,vchunk,bchunk)
                                tok_ids = tok_ids.permute(0, 2, 1).contiguous().view(Bflat, vchunk)

                            tmp_slice = tmp[:, :, :vchunk, :, :]  # view

                            for j in range(vchunk):
                                tok = tok_ids[:, j:j + 1]  # (Bflat,1)
                                h = _forward_one_collect(model, tok, kv_caches, activation=activation)
                                # h: (n_layers,Bflat,D) -> (n_layers,nK,bchunk,D)
                                tmp_slice[:, :, j, :, :].copy_(h.view(n_layers, nK, bchunk, D))

                            out[:, k0:k1, t, v0:v1, b0:b1, :].copy_(tmp_slice, non_blocking=async_copy)

                    del kv_caches

        if async_copy:
            torch.cuda.synchronize(device)

    finally:
        _set_flash_flags(model, flash_flags)

    return out
