from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, List, Optional

import torch

ActivationKind = Literal["attn_block", "mlp"]


def _get_n_emb(config) -> int:
    n_emb = getattr(config.model, "emb_dim", getattr(config.model, "n_embd", None))
    if n_emb is None:
        raise ValueError("config.model must contain emb_dim or n_embd")
    return int(n_emb)


@dataclass
class _MultiLayerHookBank:
    """Register forward hooks on modules and store extracted vectors (Bflat, D) per layer."""
    modules: List[torch.nn.Module]
    pos: torch.Tensor  # (Bflat,) long on same device as module outputs
    store: List[Optional[torch.Tensor]] = None
    _rows: Optional[torch.Tensor] = None

    def __post_init__(self):
        self.handles: List[torch.utils.hooks.RemovableHandle] = []
        self.store = [None] * len(self.modules)

    def __enter__(self):
        def make_hook(i: int):
            def hook(_module, _inp, out: torch.Tensor):
                if out.ndim != 3:
                    raise RuntimeError(f"Expected 3D (B,S,D) output, got {tuple(out.shape)}")
                # out: (Bflat, S, D)
                if (
                    self._rows is None
                    or self._rows.numel() != out.size(0)
                    or self._rows.device != out.device
                ):
                    self._rows = torch.arange(out.size(0), device=out.device)
                self.store[i] = out[self._rows, self.pos].detach()  # (Bflat, D)
            return hook

        for i, m in enumerate(self.modules):
            self.handles.append(m.register_forward_hook(make_hook(i)))
        return self

    def __exit__(self, exc_type, exc, tb):
        for h in self.handles:
            h.remove()


@torch.inference_mode()
def compute_hiddens_onepos_all_layers_fast(
    config,
    model: torch.nn.Module,
    sampler,
    samples: torch.Tensor,
    *,
    activation: ActivationKind = "attn_block",
    dtype_out: torch.dtype = torch.float16,
    # chunk sizes (OOM control)
    k_step: int = 4,
    t_step: int = 32,
    v_step: int = 64,
    b_step: int = 32,
    # transfer / memory
    pin_samples: bool = True,
    pin_output: bool = False,
) -> torch.Tensor:
    """Extract per-layer hidden at pos(t)=2*t+1 for all (k,t,v,b).

    samples: (n_tasks, Tm1, V, B, Sfull) on CPU
    returns: (n_layers, n_tasks, Tm1, V, B, D) on CPU

    Speed tweak: for each t-chunk we truncate the fed sequence length to L=max_pos+1,
    since causal attention means later tokens can't affect earlier positions.
    """
    model_device = next(model.parameters()).device
    on_cuda = (model_device.type == "cuda")
    model.eval()

    if samples.device.type != "cpu" or samples.ndim != 5:
        raise ValueError("samples must be a 5D CPU tensor")
    if samples.dtype != torch.long:
        samples = samples.long()
    if on_cuda and pin_samples:
        samples = samples.pin_memory()

    n_tasks, Tm1, V, B, Sfull = samples.shape
    D = _get_n_emb(config)
    n_layers = len(model.layers)

    if activation == "attn_block":
        modules = [layer.attn_block for layer in model.layers]
    elif activation == "mlp":
        modules = [layer.mlp for layer in model.layers]
    else:
        raise ValueError("activation must be \"attn_block\" or \"mlp\"")


    out_pin = bool(on_cuda and pin_output)
    out = torch.empty(
        (n_layers, n_tasks, Tm1, V, B, D),
        device="cpu",
        dtype=dtype_out,
        pin_memory=out_pin,
    )
    async_copy = bool(on_cuda and out_pin)

    # Disable output head if present (avoid logits materialization)
    has_output_layer = hasattr(model, "output_layer")
    if has_output_layer:
        old_head = model.output_layer
        model.output_layer = torch.nn.Identity()

    try:
        for k0 in range(0, n_tasks, max(1, k_step)):
            k1 = min(k0 + max(1, k_step), n_tasks)
            nK = k1 - k0

            for t0 in range(0, Tm1, max(1, t_step)):
                t1 = min(t0 + max(1, t_step), Tm1)
                tchunk = t1 - t0

                pos_by_t = (2 * torch.arange(t0, t1, dtype=torch.long) + 1)  # (tchunk,)
                max_pos = int(pos_by_t[-1].item())
                if max_pos >= Sfull:
                    raise ValueError("pos(t) exceeds sequence length")

                # Truncate sequence length for this t-chunk
                L = min(max_pos + 1, Sfull)

                for v0 in range(0, V, max(1, v_step)):
                    v1 = min(v0 + max(1, v_step), V)
                    vchunk = v1 - v0

                    for b0 in range(0, B, max(1, b_step)):
                        b1 = min(b0 + max(1, b_step), B)
                        bchunk = b1 - b0

                        # block: (nK, tchunk, vchunk, bchunk, L)
                        block = samples[k0:k1, t0:t1, v0:v1, b0:b1, :L].contiguous()
                        batch = block.view(-1, L)  # (Bflat, L)

                        if on_cuda:
                            batch = batch.to(model_device, non_blocking=True)

                        # per-row positions matching flatten order (k, t, v, b)
                        pos = pos_by_t.repeat_interleave(vchunk * bchunk).repeat(nK)  # (Bflat,)
                        if on_cuda:
                            pos = pos.to(model_device, non_blocking=True)

                        with _MultiLayerHookBank(modules, pos) as bank:
                            _ = model(batch)

                            for li, vec in enumerate(bank.store):
                                if vec is None:
                                    raise RuntimeError(f"Hook missing for layer {li}")
                                vec = vec.view(nK, tchunk, vchunk, bchunk, D).to(dtype_out)
                                out[li, k0:k1, t0:t1, v0:v1, b0:b1].copy_(
                                    vec,
                                    non_blocking=async_copy,
                                )
                                bank.store[li] = None  # free asap

                        del block, batch, pos

        if async_copy:
            torch.cuda.synchronize(model_device)

    finally:
        if has_output_layer:
            model.output_layer = old_head

    return out
